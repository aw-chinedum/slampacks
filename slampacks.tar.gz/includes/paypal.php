<?php
  class Slampacks_Paypal{
    public static $clientID = 'Ae1Yi0yvUy-d7ebI6Km31qETpEGIzdiScws_TrvRHjjZDfl1vOWlkMoCruNCMmsdiWU4Z-B8j1nVBhxP';
  
    public function load_paypal($order=[]){
    echo '
    <!-- Set up a container element for the button -->
    <div id="paypal-button-container"></div>
    
    
    <script src="https://www.paypal.com/sdk/js?client-id='.Slampacks_Paypal::$clientID.'&currency=USD&intent=capture"&data-client-token="'.$_SESSION['username'].'"></script>
    ';
    
    echo "
        <script>
          const fundingSources = [
            paypal.FUNDING.PAYPAL,
              paypal.FUNDING.CARD
            ]

          for (const fundingSource of fundingSources) {
            const paypalButtonsComponent = paypal.Buttons({
              fundingSource: fundingSource,

              // optional styling for buttons
              // https://developer.paypal.com/docs/checkout/standard/customize/buttons-style-guide/
              style: {
                shape: 'rect',
                height: 40,
              },

              // set up the transaction
              createOrder: (data, actions) => {
                // pass in any options from the v2 orders create call:
                // https://developer.paypal.com/api/orders/v2/#orders-create-request-body
                const createOrderPayload = {
                  intent: 'CAPTURE',
                  purchase_units: [
                    {
                      amount: {
                        currency_code: 'USD',
                        value: '".$order['order_total'].".00',
                      },
                    },
                  ],
                }

                return actions.order.create(createOrderPayload)
              },

              // finalize the transaction
              onApprove: (data, actions) => {
                const captureOrderHandler = (details) => {
                  const payerName = details.payer.name.given_name
                  console.log('Transaction completed!')
                }

                return actions.order.capture().then(captureOrderHandler)
              },

              // handle unrecoverable errors
              onError: (err) => {
                console.error(
                  'An error prevented the buyer from checking out with PayPal',
                )
              },
            })

            if (paypalButtonsComponent.isEligible()) {
              paypalButtonsComponent
                .render('#paypal-button-container')
                .catch((err) => {
                  console.error('PayPal Buttons failed to render')
                })
            } else {
              console.log('The funding source is ineligible')
            }
          }
        </script>";
    }
  }


?>
